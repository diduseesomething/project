1) Задание

1. Требуется выполнить анализ компонента zlib с открытым исходным кодом.
В директории /home/user/zlib размещён репозиторий системы управления версиями GIT содержащий исходные коды анализируемой библиотеки.
2. Анализ необходимо выполнить для исходного кода, зафиксированного в ветке v1.2.0
$git checkout v1.2.0
3. Изучить секцию BUILDING в файле README и FAQ
4. Проанализировать используемые при сборке значения переменных для скрипта configure 
$./configure -h
5. Сконфигурировать компоненту zlib для сборки в качестве разделяемой библиотеки 
$./configure
$./configure --shared
6. Изучить документацию на статический анализатор (doc/svace/README-3.4.240516.txt)
7. Выполнить сборку под контролем статического анализатора
$svace build --init make
$svace analyze
$svacer import
8. Выполнить разметку не менее 3-х предупреждений, на выбор:
Детектор	Сработка
DEREF_OF_NULL.EX.COND	 gzio.c:111
PROC_USE.VULNERABLE	 gzio.c:113
PROC_USE.VULNERABLE	 gzio.c:928
PROC_USE.VULNERABLE	 gzio.c:929
FALL_THROUGH	 inflate.c:616
FALL_THROUGH	 inflate.c:621
FALL_THROUGH	 inflate.c:629
FALL_THROUGH	 inflate.c:657
FALL_THROUGH	 inflate.c:671
FALL_THROUGH	 inflate.c:690
FALL_THROUGH	 inflate.c:697
FALL_THROUGH	 inflate.c:920
PASS_TO_PROC_AFTER_CHECK	 minigzip.c:181
PROC_USE.VULNERABLE	 minigzip.c:203
PROC_USE.VULNERABLE	 minigzip.c:204
PROC_USE.VULNERABLE	 minigzip.c:234
PROC_USE.VULNERABLE	 minigzip.c:243
UNCHECKED_FUNC_RES.STAT	 uncompr.c:51

9.Выполнить описание разметки в полном объеме, допускающем выполнение кросс-верификации без проведения повторного анализа (в соответствии с регламентом Центра).
Детектор	       Сработка	         Вердикт	Комментарий
DEREF_OF_NULL.EX.COND	gzio.c:111 	 Confirmed	При выделение памяти для `s` 
							используется `malloc` из-за 
							чего может `s->stream .state != NULL`
							и поле `mode` может быть равно `w` (119)

PROC_USE.VULNERABLE	gzio.c:113	Won't fix	Для `s->path` выделяется достаточно
							памяти для копирования `path`

PROC_USE.VULNERABLE	gzio.c:928	Won't fix	Для `s->msg` выделяется необходимое 
							количество памяти

PROC_USE.VULNERABLE	gzio.c:929	Won't fix	Для `s->msg` выделяется необходимое
							количество памяти

FALL_THROUGH	inflate.c:616	Won't fix	Подразумевается переход к следующему
						`case` и `switch` в бесконечном цикле

FALL_THROUGH	inflate.c:621	Won't fix	Подразумевается переход к следующему
						`case` и `switch` в бесконечном цикле

FALL_THROUGH	inflate.c:629	Won't fix	Подразумевается переход к следующему
						`case` и `switch` в бесконечном цикле

FALL_THROUGH	inflate.c:657	Won't fix	Подразумевается переход к следующему
						`case` и `switch` в бесконечном цикле

FALL_THROUGH	inflate.c:671   Won't fix	Подразумевается переход к следующему
						`case` и `switch` в бесконечном цикле

FALL_THROUGH	inflate.c:690 	Won't fix	Подразумевается переход к следующему
						`case` и `switch` в бесконечном цикле

FALL_THROUGH	inflate.c:697 	Won't fix	Подразумевается переход к следующему
						`case` и `switch` в бесконечном цикле

FALL_THROUGH	inflate.c:920	Won't fix	Подразумевается переход к следующему
						`case` и `switch` в бесконечном цикле

PASS_TO_PROC_AFTER_CHECK     minigzip.c:181	 False positive	       Если `len` отрицательный то 
									в `error` вызовется `exit(1)`

PROC_USE.VULNERABLE	minigzip.c:203:   :	 Confirmed	Может произойти переполнение если `file` 
								будет иметь длину больше `1023` - в `main` 
								туда может передаваться `*argv` а его максимальная 
								длина может значительно превышать это значение

PROC_USE.VULNERABLE	minigzip.c:204:   :	 Confirmed	Может произойти переполнение если `file` 
								будет иметь длину больше `1020` - в `main` 
								туда может передаваться `*argv` а его максимальная 
								длина может значительно превышать это значение

PROC_USE.VULNERABLE	minigzip.c:234:   :	 Confirmed	Может произойти переполнение если `file` 
								будет иметь длину больше `1023` - в `main` 
								туда может передаваться `*argv` а его максимальная 
								длина может значительно превышать это значение

PROC_USE.VULNERABLE	minigzip.c:243 	         Confirmed	 Может произойти переполнение если `file` 
								 будет иметь длину больше `1020` - в `main` 
								 туда может передаваться `*argv` а его максимальная 
								 длина может значительно превышать это значение

UNCHECKED_FUNC_RES.STAT	 uncompr.c:51	         Won't fix	 `inflateEnd` вызывается здесь для попытки высвобождения 
								 ресурсов потока т.к. последний вызов `inflate`
								 не был успешным

10. Представить параметры и результаты успешной сборки, разметку трёх предупреждений

____________________________________________________________________________________

2) Документация

1. Документация на svace  - /doc/svace
2. Документация на svacer - /svacer
3. Документа на zlib      - /home/user/zlib
_____________________________________________________________________________________

3) Инструкция по выгрузке результатов на кафедральный svacer по локальной сети

svacer import --svace svace <путь_до_проекта>
svacer upload --user <логин> --password <пароль> --host 10.10.1.19 --port 8080 <путь_до_проекта>

Для авторизации использовать использовать предоставленные логин/пароль