1) Задание

1. Требуется выполнить анализ компонента libsocket с открытым исходным кодом.
В директории /home/user/libsocket размещён репозиторий системы управления версиями GIT, содержащий исходные коды анализируемой библиотеки.
2. Анализ необходимо выполнить для исходного кода зафиксированного в коммите: b4f5193fae541d4bf21db0cbc7af5d2ad540134f
$git checkout b4f5193fae541d4bf21db0cbc7af5d2ad540134f
3. Изучить секцию BUILDING в файле README.md и проанализировать используемые при сборке значения переменных cmake
$ cmake -LAH
5. Сконфигурировать libsocket для сборки в качестве статической библиотеки
$mkdir build && cd build
$cmake .. -DBUILD_STATIC_LIBS:BOOL=ON
6. Изучить документацию на статический анализатор (doc/svace/README-3.4.240516.txt)
7. Выполнить сборку под контролем статического анализатора
$svace build --init make
$svace analyze
$svacer import --upload
8. Выполнить разметку не менее чем 3-х предупреждений, на выбор:
Детектор	Сработка
DOUBLE_CLOSE	 libinetsocket.c:221
HANDLE_LEAK	 libunixsocket.c:149
HANDLE_LEAK	 libunixsocket.c:195
HANDLE_LEAK	 libunixsocket.c:377
HANDLE_LEAK.EX	 libinetsocket.c:263
HANDLE_LEAK.EX	 libinetsocket.c:266
HANDLE_LEAK	 libinetsocket.c:924
HANDLE_LEAK	 libinetsocket.c:997
NULL_AFTER_DEREF	 libunixsocket.c:458
UNCHECKED_FUNC_RES.STAT	 libunixsocket.c:204
UNINIT.CTOR	 inetbase.cpp:53
UNINIT.LOCAL_VAR	 libinetsocket.c:221

9.Выполнить описание разметки в полном объеме, допускающем выполнение кросс-верификации без проведения повторного анализа (в соответствии с регламентом Центра)
Детектор	Сработка	                Вердикт	        Комментарий
DOUBLE_CLOSE	libinetsocket.c:221        	Confirmed	Если цикл дойдёт до конца списка `result_check`
                                                                не прерываясь,то последний сокет будет закрыт
                                                                дважды, что может повлиять 
                                                                на параллельные потоки

HANDLE_LEAK	libunixsocket.c:149	      False positive	Если дескриптор < 0,
                                                                то закрывать его не нужно

	        libunixsocket.c:195	      False positive	Если дескриптор < 0,
 								то закрывать его не нужно

	        libunixsocket.c:377	      False positive	Если дескриптор < 0,
								то закрывать его не нужно

HANDLE_LEAK.EX	libinetsocket.c:263	      False positive	Если дескриптор < 0,
								то закрывать его не нужно

	        libinetsocket.c:266	      False positive	Если дескриптор < 0,
								то закрывать его не нужно

HANDLE_LEAK	libinetsocket.c:924	         Confirmed	`result` должен высвобождаться по 
								окончанию использования с помощью 
								`freeaddrinfo`

	        libinetsocket.c:997	         Confirmed	`result` должен высвобождаться по
								окончанию использования с помощью
								`freeaddrinfo`

NULL_AFTER_DEREF	libunixsocket.c:458	 Confirmed	`memset` вызывается перед
								проверкой на `NULL`

UNCHECKED_FUNC_RES.STAT	libunixsocket.c:204	 Won't fix	Проверка не имеет смысла, т.к.
								здесь по условию `retval` точно 
								равен `-1`, 
                                                                результат`check_error` будет `-1`

UNINIT.CTOR	        inetbase.cpp:53	         Won't fix	Это базовый класс, от которого 
								наследуются указанные в сработке 
								классы. В их реализации данное 
								поле не используется

UNINIT.LOCAL_VAR	libinetsocket.c:221	False positive	`sfd` будет неинициализированным
								только если будет пропущен цикл. 
								Это произойдёт, если `result` равен 
								`NULL`. `result_check` тоже будет 
								`NULL`, из-за чего вызова этого 
								`close` не будет

10. Представить параметры и результаты успешной сборки, разметку трёх предупреждений
____________________________________________________________________________________

2) Документация

1. Документация на svace  - /doc/svace
2. Документация на svacer - /svacer
3. Документа на libsocket - /home/user/libsocket
_____________________________________________________________________________________

3) Инструкция по выгрузке результатов на кафедральный svacer по локальной сети

svacer import --svace svace <путь_до_проекта>
svacer upload --user admin --password admin --host 10.10.1.58 --port 8080 <путь_до_проекта>

Для авторизации использовать использовать предоставленные логин/пароль


